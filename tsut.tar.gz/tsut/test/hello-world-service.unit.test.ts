import {  test, timeout } from '@testdeck/mocha';
import * as _chai from 'chai';
import axios from 'axios';
import * as webdriver from 'selenium-webdriver';
const Suite = Mocha.Suite;
const Test = Mocha.Test;
const mocha = new Mocha();
let suite = Suite.create(mocha.suite, "test1");
axios.get("https://api.github.com/users", {
    headers: {
        'Content-Type': 'application/json',
        Accept: "application/vnd.github.v3+json"
    }
}).then(response => {
    response.data.filter(value =>  value.id===36 || value.id === 35).forEach(value=>{

        var testCase = new Test(test.name, async() =>  {
            let driver = new webdriver.Builder()
            .withCapabilities(webdriver.Capabilities.chrome())
            .build();
            console.log("message 2")
        // maximizing chrome browser 
            driver.manage().window().maximize();

            console.log("message a")
            await driver.get(`https://the-internet.herokuapp.com/login`)
            console.log("message c")            
        });
        testCase.timeout(600000);
        suite.timeout(600000);
        suite.addTest(testCase);
  
    })
}).then(()=>{
    mocha.run();
})
