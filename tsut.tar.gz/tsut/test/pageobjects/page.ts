/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
import * as webdriver from 'selenium-webdriver';
import * as fs from 'fs';
import { should } from 'chai'

export default class Page {
    driver:any;
    /**
    * Opens a sub page of the page
    * @param path path of the sub page (e.g. /path/to/page.html)
    */
    public async open(path: string) {
        console.log("message 1")
        this.driver = new webdriver.Builder()
            .withCapabilities(webdriver.Capabilities.chrome())
            .build();
            console.log("message 2")
        // maximizing chrome browser 
        this.driver.manage().window().maximize();
        console.log("message 3")        
        await this.driver.get(`https://the-internet.herokuapp.com/${path}`);
        return this.driver; 

    }
    public async getDriver(){
        console.log("message 1")
        this.driver = new webdriver.Builder()
            .withCapabilities(webdriver.Capabilities.chrome())
            .build();
            console.log("message 2")
        // maximizing chrome browser 
        this.driver.manage().window().maximize();
        return this.driver;
    }
}
