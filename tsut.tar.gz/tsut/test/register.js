/**
 * Overrides the tsconfig used for the app.
 * In the test environment we need some tweaks.
 */



const tsNode = require('ts-node');
const testTSConfig = require('./test/tsconfig.json');

tsNode.register({
  files: true,
  transpileOnly: true,
  project: './test/tsconfig.json'
});


process.env.TS_NODE_PROJECT = './test/tsconfig.json';
require('ts-mocha');
const Mocha = require('mocha');

const mocha = new Mocha();
mocha.addFile(`./test/hello-world-service.unit.test.ts`);
mocha.run((failures) => {
  process.on('exit', () => {
    process.exit(failures); // exit with non-zero status if there were failures
  });
});
global.Mocha = Mocha;
global.mocha = mocha;